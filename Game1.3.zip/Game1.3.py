import pygame       # Stellt Objekte und Konstanten zur Spielprogrammierung zur Verfügung
import os
import random

class Settings(object):
    width = 600                 #Posizionierung des Fensters
    height = 700
    title = "Game1.3"           #Name des Spiels
    fps = 60                    #Begrenzung der Frames pro Sekunde
    file_path = os.path.dirname(os.path.abspath(__file__))
    images_path = os.path.join(file_path, "images2")        #Auswahl des Ortners wo alles drin ist
    score = 0
    

    @staticmethod
    def get_dim():
        return (Settings.width, Settings.height)


class Character(pygame.sprite.Sprite):
    def __init__(self, pygame):
        super().__init__()
        self.image = pygame.image.load(os.path.join(Settings.images_path, "Character.png")).convert_alpha()  #auwahl des bildes
        self.image = pygame.transform.scale(self.image, (30, 65))               #skalliert das bild
        self.rect = self.image.get_rect()
        self.space = False
        self.rect.left = (Settings.width - self.rect.width) // 2                #Posizionierung des characters
        self.rect.top = (Settings.height - self.rect.height) 
        self.direction = 0
        self.speed = 5

    def update(self):
       # Steuerung mit Pfeiltasten
        if pygame.key.get_pressed()[pygame.K_LEFT] == True:
           self.rect.left -= self.speed

        if pygame.key.get_pressed()[pygame.K_RIGHT] == True:
            self.rect.left += self.speed

        if pygame.key.get_pressed()[pygame.K_UP] == True:
           self.rect.top -= self.speed

        if pygame.key.get_pressed()[pygame.K_DOWN] == True:
            self.rect.top += self.speed

        # Kollision mit dem Rand
        if self.rect.left <= 0:
            self.rect.left = 0
        if self.rect.right >= Settings.width:
            self.rect.right = Settings.width
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= Settings.height:
            self.rect.bottom = Settings.height

        # Teleportation beim loslassen der Leertaste
        if pygame.key.get_pressed()[pygame.K_SPACE] == True:
            self.space = True
        if pygame.key.get_pressed()[pygame.K_SPACE] == False and self.space == True:
            self.rect.top = random.randrange(0, Settings.height - self.rect.height)
            self.rect.left = random.randrange(0, Settings.width - self.rect.width)
            self.space = False

class Cloud(pygame.sprite.Sprite):
    def __init__(self, enemysprite):
        super().__init__()
        self.image = pygame.image.load(os.path.join(Settings.images_path, "Wolke2.png")).convert_alpha()
        self.image = pygame.transform.scale(self.image, (random.randrange(95,120),random.randrange(30,45)))
        self.rect = self.image.get_rect()
        self.rect.bottom = random.randrange(-1500, 0)
        self.rect.left = random.randrange(0, 499)
        if Settings.score <= 10:
            self.speed = random.randrange(2, 4)
        if Settings.score >= 40:
            self.speed = random.randrange(4, 6)
        if Settings.score >= 80:
            self.speed = random.randrange(6, 8)
        if Settings.score >= 120:
            self.speed = random.randrange(8, 10)

    def update(self):
        self.rect.bottom += self.speed
        if self.rect.top >= 700:
            self.rect.bottom = random.randrange(-1500, 0)
            self.rect.left = random.randrange(0, 499)
           

class Game(object):
    def __init__(self):
        self.screen = pygame.display.set_mode(Settings.get_dim())
        pygame.display.set_caption(Settings.title)

        self.background = pygame.image.load(os.path.join(Settings.images_path, "background2.png")).convert()
        self.background = pygame.transform.scale(self.background, (Settings.width, Settings.height))
        self.background_rect = self.background.get_rect()

        self.all_character = pygame.sprite.Group()      #erstellung der gruppe
        self.character = Character(pygame)              #erstellung des character
        self.all_character.add(self.character)  	    #packt den character in die gruppe
        self.all_cloud = pygame.sprite.Group()      
        self.anzahl_cloud = 0
        self.clock = pygame.time.Clock()
        self.done = False

    def run(self):
        while not self.done:             # Hauptprogrammschleife mit Abbruchkriterium   
            self.clock.tick(Settings.fps)          # Setzt die Taktrate auf max 60fps   
            for event in pygame.event.get():    # Durchwandere alle aufgetretenen  Ereignisse
                if event.type == pygame.QUIT:   # Wenn das rechts obere X im Fenster geklickt
                    self.done = True                 # Flag wird auf Ende gesetzt
            collision = pygame.sprite.spritecollide(self.character, self.all_cloud, False)      # Kollisionsabfage
            if collision:                             
                self.done = True                            # Beendet das Spiel bei Kollision
            if Settings.score <= 10:
                if self.anzahl_cloud < 5:
                    self.anzahl_cloud += 1
                    self.cloud = Cloud(pygame)                  # Die Klasse cloud wir erschaffen
                    self.all_cloud.add(self.cloud)              # cloud wird in die Gruppe hinzugfügt
            if Settings.score >= 40:
                if self.anzahl_cloud < 8:
                    self.anzahl_cloud += 1 
                    self.cloud = Cloud(pygame)                  # Die Klasse cloud wir erschaffen
                    self.all_cloud.add(self.cloud)              # cloud wird in die Gruppe hinzugfügt
            if Settings.score >= 80:
                if self.anzahl_cloud < 10:
                    self.anzahl_cloud += 1 
                    self.cloud = Cloud(pygame)                  # Die Klasse cloud wir erschaffen
                    self.all_cloud.add(self.cloud)              # cloud wird in die Gruppe hinzugfügt
            if Settings.score >= 120:
                if self.anzahl_cloud < 12:
                    self.anzahl_cloud += 1 
                    self.cloud = Cloud(pygame)                  # Die Klasse cloud wir erschaffen
                    self.all_cloud.add(self.cloud)              # cloud wird in die Gruppe hinzugfügt
                    


            self.screen.blit(self.background, self.background_rect)
            self.all_character.draw(self.screen)
            self.all_character.update()
            self.all_cloud.update()
            self.all_cloud.draw(self.screen)
            pygame.display.flip()   # Aktualisiert das Fenster


if __name__ == '__main__':      #                      
    pygame.init()               # Bereitet die Module zur Verwendung vor  
    game = Game()
    game.run()
    pygame.quit()               #beendet pygame


    #wenn eine wolke unten ankommt wird der score um 1 erhöt
    # score oben links einblenden lassen