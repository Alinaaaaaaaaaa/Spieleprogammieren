import pygame
import os
import random

class Settings():
    breite = 800
    höhe = 600
    title = "Bubblegame"
    file_path = os.path.dirname(os.path.abspath(__file__))
    images_path = os.path.join(file_path, "images")
    fps = 60
    punkte = 0
    zeit = 60
    rand = 10
    blasen = 0
    Spiel_Ende = False
    try:
        Datei = open("highscore.txt", "r")
        highscore = int(Datei.readline())
        Datei.close()
    except:
        Datei = open("highscore.txt", "w")
        Datei.write(str(0))
        Datei.close()
        highscore = 0

    @staticmethod
    def get_dim():
        return (Settings.breite, Settings.höhe)
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
class Seeigel(pygame.sprite.Sprite):
    def __init__(self, pygame):
        super().__init__()
        self.image = pygame.image.load(os.path.join(Settings.images_path, "Mauszeiger.png")).convert_alpha()  #auwahl des bildes
        self.image = pygame.transform.scale(self.image, (40, 40))               #skalliert das bild
        self.rect = self.image.get_rect()
        self.kollision = False
  
    def update(self):
        # Maus Steuerung
        self.rect.top = pygame.mouse.get_pos()[1] - 20
        self.rect.left = pygame.mouse.get_pos()[0] - 20
        if self.kollision == True:
            self.image = pygame.image.load(os.path.join(Settings.images_path, "Mauszeiger2.png")).convert_alpha()
            self.image = pygame.transform.scale(self.image, (40, 40)) 
        else:
            self.image = pygame.image.load(os.path.join(Settings.images_path, "Mauszeiger.png")).convert_alpha()
            self.image = pygame.transform.scale(self.image, (40, 40)) 
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
class Blase(pygame.sprite.Sprite):
    def __init__(self, pygame):
        super().__init__()
        self.bild = random.choice(["BlaseB.png", "BlaseG.png", "BlaseT.png", "BlaseP.png", "BlaseL.png"])
        self.image = pygame.image.load(os.path.join(Settings.images_path, self.bild)).convert_alpha()
        self.image = pygame.transform.scale(self.image,(10, 10))
        self.rect = self.image.get_rect()
        self.rect.top = random.randrange(0 + Settings.rand, Settings.höhe - self.rect.height - Settings.rand)
        self.rect.left = random.randrange(0 + Settings.rand, Settings.breite - self.rect.width - Settings.rand)
        self.wachstumsrate = random.randrange(1, 5)
        self.zeit = 0
        self.radius = 5
        Settings.blasen += 1
        
    def update(self):
        # Wachstumsrate der Blase 
        self.zeit += 1
        if self.zeit >= Settings.zeit:
            self.radius += self.wachstumsrate
            self.image = pygame.image.load(os.path.join(Settings.images_path, self.bild)).convert_alpha()
            self.image = pygame.transform.scale(self.image,(self.radius*2, self.radius*2))
            self.zeit = 0
            self.rect.height += self.wachstumsrate*2
            self.rect.width += self.wachstumsrate*2
        # Blase bei Gedrückter Maus platzt
        if pygame.mouse.get_pressed()[0] and self.rect.top <= pygame.mouse.get_pos()[1] and self.rect.bottom >= pygame.mouse.get_pos()[1] and self.rect.left <= pygame.mouse.get_pos()[0] and self.rect.right >= pygame.mouse.get_pos()[0]:
            self.kill()
            Settings.blasen -= 1
            Settings.punkte += self.radius

         # Kollision mit dem Rand
        if self.rect.left <= 0:
            self.kill()
            Settings.blasen -= 1
        if self.rect.right >= Settings.breite:
            self.kill()
            Settings.blasen -= 1
        if self.rect.top <= 0:
            self.kill()
            Settings.blasen -= 1
        if self.rect.bottom >= Settings.höhe:
            self.kill()
            Settings.blasen -= 1
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
class Game(object):
    def __init__(self):
        self.screen = pygame.display.set_mode(Settings.get_dim())
        pygame.display.set_caption(Settings.title)
        self.hintergrund = pygame.image.load(os.path.join(Settings.images_path, "Hintergrund.png")).convert()
        self.hintergrund  = pygame.transform.scale(self.hintergrund, (Settings.breite, Settings.höhe))
        self.hintergrund_rect = self.hintergrund.get_rect()
        self.clock = pygame.time.Clock()
        self.Ende = False

        self.all_seeigel = pygame.sprite.Group()      #erstellung der gruppe
        self.seeigel = Seeigel(pygame)              #erstellung des character
        self.all_seeigel.add(self.seeigel)  	    #packt den character in die gruppe
        self.all_blase = pygame.sprite.Group()      
        self.zeit = 0
        pygame.mouse.set_visible(False)
        self.font = pygame.font.SysFont("Algerian", 30)


    def run(self):
        while not self.Ende:             # Hauptprogrammschleife mit Abbruchkriterium   
            self.clock.tick(Settings.fps)          # Setzt die Taktrate auf max 60fps   
            for event in pygame.event.get():    # Durchwandere alle aufgetretenen  Ereignisse
                if event.type == pygame.QUIT:   # Wenn das rechts obere X im Fenster geklickt
                    self.Ende = True                 # Flag wird auf Ende gesetzt
            collision = pygame.sprite.spritecollide(self.seeigel, self.all_blase, False)      # Kollisionsabfage
            if collision:
                self.seeigel.kollision = True
            else:
                self.seeigel.kollision = False
            

            self.screen.blit(self.hintergrund, self.hintergrund_rect)
            self.zeit += 1
            if self.zeit >= Settings.zeit and Settings.blasen <= Settings.breite/60:
                self.zeit = 0
                self.blase = Blase(pygame)              
                self.all_blase.add(self.blase)
                if Settings.zeit > 15:
                    Settings.zeit -= 1

            if Settings.highscore < Settings.punkte:
                    Settings.highscore = Settings.punkte

            self.highscoretext = self.font.render("Highscore: " + str(Settings.highscore) , False , (150,250,250))
            self.screen.blit(self.highscoretext, (5, 30))

            self.all_blase.update()
            self.all_blase.draw(self.screen)            
            self.all_seeigel.draw(self.screen)
            self.all_seeigel.update()
            
            self.punktetext = self.font.render("punkte: " + str(Settings.punkte) , False , (150,250,250))
            self.screen.blit(self.punktetext, (5, 0))

            pygame.display.flip()   # Aktualisiert das Fenster


            for blase in self.all_blase:
                for blase2 in self.all_blase:
                    if blase != blase2:
                        collision = pygame.sprite.collide_circle(blase, blase2)
                        if collision == True:
                            self.Ende = True
                            Datei = open("highscore.txt", "w")
                            Datei.write(str(Settings.highscore))
                            Datei.close()


if __name__ == '__main__':                      
    pygame.init()               # Bereitet die Module zur Verwendung vor  
    game = Game()
    game.run()
    pygame.quit()               #beendet pygame